# -*- coding: utf-8 -*-

from odoo import api, models, fields


class BulkUploadBook(models.Model):
    _name = "bulk.upload.book"
    _description = "Bulk upload book"

    book_names = fields.Text(
        string="Book Names")
    author = fields.Many2one(
        comodel_name='res.partner',
        string="Author")
    category = fields.Char(
        string="Category")
    price = fields.Float(
        string="Price")
    created_book_count = fields.Integer(
        compute='_compute_created_book_count',
        string="Created Books"
    )

    def create_book(self):
        print("\n\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>create bulk book\n")

    def revert_changes(self):
        print("\n\n:::::::::::::::::::::::::::revert changes\n")

    @api.depends('author')
    def _compute_created_book_count(self):
        """
        This method is used to calculate Borrowed books count which are available in borrow state.
        """
        for book in self:
            book.created_book_count=0

    def action_create_book(self):
        print("\n?????????????????????????created book show\n")